import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  datosTabla = [
    {usuario:'user_prueba',email:'correo@prueba.com',nombres:'Prueba',apellidos:'Tecnica',activo:'Activo'}
  ];

  //Filtros
  filtroEmail:string = '';
  filtroUsuario:string = '';
  filtroNombres:string = '';
  filtroApellidos:string = '';
  constructor() { }

  ngOnInit(): void {
  }

  filtro(){
    
  }

}
